package exceptions;

public class TaskInputDateException extends Exception {
    public TaskInputDateException(final String message) {
        super(message);
    }
}
