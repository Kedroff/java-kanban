package tasks;

public enum TaskStatuses {
    DONE,
    IN_PROGRESS,
    NEW
}
