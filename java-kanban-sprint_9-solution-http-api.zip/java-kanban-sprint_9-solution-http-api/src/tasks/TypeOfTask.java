package tasks;

public enum TypeOfTask {
    TASK,
    EPIC,
    SUBTASK
}
